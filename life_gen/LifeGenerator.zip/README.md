# Life Generator

## Requirements

`python3`
`pip`

## Install Dependencies

`python3 -m pip install pandas`

## Run

`python life-generator.py [<input.csv>]`
